package com.hotelmgmt.exception;

public class HotelMgmtException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public HotelMgmtException()
	{
		
	}
	
}
