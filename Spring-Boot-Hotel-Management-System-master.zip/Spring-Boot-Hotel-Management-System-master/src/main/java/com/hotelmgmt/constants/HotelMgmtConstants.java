package com.hotelmgmt.constants;

public final class HotelMgmtConstants {
	
	public static final String ADD_SUCCESS = " added successfully.";
	
	public static final String DELETE_SUCCESS = " deleted successfully.";
	
	public static final String PATCH_SUCCESS = " patched successfully.";
	
	public static final String FILTER_COLUMN = "city";
	
	public static final String FILTER_OPERATION = ":";
}
