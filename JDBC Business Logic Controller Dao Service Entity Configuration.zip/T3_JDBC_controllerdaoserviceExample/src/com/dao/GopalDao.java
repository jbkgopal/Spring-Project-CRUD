package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.configuration.DBConfiguration;
import com.entity.Gopal;

// Data Transfer from DataBase - setData and getData
public class GopalDao {

	// getAllGopalRecord() -> This method use for Get All Data in DataBase
	public ArrayList<Gopal> getAllGopalRecord() throws Exception {
		Connection con = DBConfiguration.getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("select * from gopal");
		Gopal gg = new Gopal();
		ArrayList<Gopal> al = new ArrayList<>();
		while (rs.next()) {
			int id = rs.getInt(1);
			String name = rs.getString(2);
			System.out.println(id + " " + name);
			gg.setId(id);
			gg.setName(name);
			al.add(gg);
		}
		return al;
	}

	// insertGopalRecord(int id, String name) -> This method use for Insert a single Data in DataBase
	public void insertGopalRecord(int id, String name) throws Exception {
		Connection con = DBConfiguration.getConnection();
		PreparedStatement ps = con.prepareStatement("insert into gopal (id,name) values (?,?)");
		ps.setInt(1, id);
		ps.setString(2, name);
		ps.executeUpdate();
		System.out.println("Record Inserted..." + ps);
	}

	// updateGopalRecord(int id, String name) -> This method use for Update a single Data in DataBase
	public void updateGopalRecord(int id, String name) throws Exception {
		Connection con = DBConfiguration.getConnection();
		PreparedStatement ps = con.prepareStatement("update gopal set name=? where id=?");
		ps.setString(1, name);
		ps.setInt(2, id);
		ps.executeUpdate();
		System.out.println("Record Updated..." + ps);
	}

	// deleteGopalRecord(int id) -> This method use for Delete a single Data in DataBase
	public void deleteGopalRecord(int id) throws Exception {
		Connection con = DBConfiguration.getConnection();
		PreparedStatement ps = con.prepareStatement("delete from gopal where id=?");
		ps.setInt(1, id);
		ps.executeUpdate();
		System.out.println("Record Updated..." + ps);
	}

}
