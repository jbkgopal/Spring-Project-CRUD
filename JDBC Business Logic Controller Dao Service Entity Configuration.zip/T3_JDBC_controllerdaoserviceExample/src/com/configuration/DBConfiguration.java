package com.configuration;

import java.sql.Connection;
import java.sql.DriverManager;

//DataBase Connection Done in a Single class  
public class DBConfiguration {

	// We can use Single method in multiple classes
	public static Connection getConnection() throws Exception{
		Class.forName("com.mysql.jdbc.Driver");
		System.out.println("Driver Load...");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/batch448", "root", "root");
		System.out.println("Connection Done...");
		return con;
	}
}
