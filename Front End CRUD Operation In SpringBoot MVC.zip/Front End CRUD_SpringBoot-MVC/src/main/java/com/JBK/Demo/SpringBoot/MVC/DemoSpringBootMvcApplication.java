package com.JBK.Demo.SpringBoot.MVC;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class DemoSpringBootMvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoSpringBootMvcApplication.class, args);
		System.out.println("SpringBoot MVC Batch 448");
	}

}
