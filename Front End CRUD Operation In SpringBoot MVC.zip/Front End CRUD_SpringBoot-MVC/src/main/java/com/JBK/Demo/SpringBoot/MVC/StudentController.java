package com.JBK.Demo.SpringBoot.MVC;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StudentController {

	@Autowired
	SessionFactory sf;
	
	// localhost:8080
	@RequestMapping("/")
	String saveJspPage() {
		return "save";
	}
	
	@RequestMapping("jspPage")
	ModelAndView m() {
		ModelAndView modelAndView=new ModelAndView();
		modelAndView.setViewName("save");
		return modelAndView;
	}

	@RequestMapping("/save")
	String saveRecord(@ModelAttribute Employee employee) {

		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		ss.save(employee);

		tx.commit();

		return null;
	}
	
	
	@RequestMapping("/updatePage")
	String updatePage() {
		return "update";
	}
	
	@RequestMapping("/update")
	String updateRecord(@ModelAttribute Employee employee) {

		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();

		ss.update(employee);

		tx.commit();

		return null;
	}
	
	
	

	@RequestMapping("/viewtablepage")
	public ModelAndView viewtable() {

		Session ss = sf.openSession();

		Query query = ss.createQuery("from Employee");

		List<Employee> al = query.list();
		al.forEach(System.out::println);

		ModelAndView view = new ModelAndView();
		view.addObject("al", al);
		System.out.println(al);
		view.setViewName("viewtable");

		return view;
	}
	
	
	
	
	
	
	

}
