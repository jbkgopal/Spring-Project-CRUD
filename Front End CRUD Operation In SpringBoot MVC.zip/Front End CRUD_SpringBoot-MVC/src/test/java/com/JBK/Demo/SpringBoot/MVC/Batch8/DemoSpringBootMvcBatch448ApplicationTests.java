package com.JBK.Demo.SpringBoot.MVC.Batch8;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoSpringBootMvcBatch448ApplicationTests {

	@Test
	void contextLoads() {
	}

}
