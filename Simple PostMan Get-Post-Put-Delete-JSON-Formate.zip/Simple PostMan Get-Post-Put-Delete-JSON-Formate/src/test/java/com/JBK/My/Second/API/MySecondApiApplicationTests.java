package com.JBK.My.Second.API;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MySecondApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
