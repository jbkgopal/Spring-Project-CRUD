package com.JBK.My.Second.API;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class MySecondApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(MySecondApiApplication.class, args);
		System.err.println("Spring Running...");
	}

}
