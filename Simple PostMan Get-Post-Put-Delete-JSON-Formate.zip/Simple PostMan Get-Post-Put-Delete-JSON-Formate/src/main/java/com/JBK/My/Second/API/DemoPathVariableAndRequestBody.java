package com.JBK.My.Second.API;

import java.util.ArrayList;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoPathVariableAndRequestBody {
	
	//  ******* Two types To Store a Data in SpringBoot Using PostMan Browser ******//
	
	// 1) baseRequestUrl/API's
	// 2) baseRequestBody
	
	// To Store a Data in baseRequestUrl/API's By Using @PathVariable Annotation
	// To Store a Data in baseRequestBody By Using @RequestBody Annotation
	
	@RequestMapping("test1/{id}")
	public int singleIdAPI(@PathVariable int id) {
		System.out.println(id);
		return id;
	}

	@RequestMapping("test2/{name}")
	public String singleNameAPI(@PathVariable String name) {
		System.out.println(name);
		return name;
	}

	@RequestMapping("test3")
	public int singleIdBody(@RequestBody int id) {
		System.out.println(id);
		return id;
	}

	@RequestMapping("test4")
	public String singleNameBody(@RequestBody String name) {
		System.out.println(name);
		return name;
	}
	
	
	// **** WithOut DataBase JSON format Temporary Data Store a Using SpringBoot http methods -> GetMapping - PostMapping - PutMapping - DeleteMapping ****//
	

	ArrayList<Student> al = new ArrayList<>();

	public DemoPathVariableAndRequestBody() {
		al.add(new Student(101, "aaaa"));
		al.add(new Student(102, "bbbb"));
	}

	@RequestMapping("showAllData")
	public ArrayList<Student> showAllData() {
		System.out.println("Show MultiPle Record -> " + al);
		return al;
	}

	@GetMapping("showSingleRecord/{id}")
	public Student singleRecord(@PathVariable int id) {
		Student student = null;
		for (Student student2 : al) {
			if (student2.id == id) {
				student = student2;
			}
		}
		System.out.println("Show Single Record -> " + student);
		return student;
	}

	@PostMapping("insertRecord")
	public Student insert(@RequestBody Student student) {
		al.add(student);
		System.out.println("Insert Single Record -> " + student);
		return student;
	}

	@PutMapping("updateRecord")
	public Student update(@RequestBody Student student) {
		Student student2 = new Student();
		student2.setId(student.id);
		student2.setName(student.name);
		System.out.println("Update Single Record -> " + student2);
		return student2;
	}

	@DeleteMapping("deleteRecord/{id}")
	public Student delete(@PathVariable int id) {
		Student student = new Student();
		for (Student student2 : al) {
			if (student2.id == id) {
				student = student2;
			}
		}
		al.remove(student);
		System.out.println("Delete Single Record -> " + student);
		return student;
	}

}
