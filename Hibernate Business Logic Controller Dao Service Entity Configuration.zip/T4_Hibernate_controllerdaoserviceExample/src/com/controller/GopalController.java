package com.controller;

import java.util.List;

import com.entity.Gopal;
import com.service.GopalService;

// To call Controller all Methods
public class GopalController {

	// getAllGopalRecord() -> This method use for Get All Data from Service Class
	public List<Gopal> getAllGopalRecord() throws Exception {
		GopalService gs = new GopalService();
		List<Gopal> al = gs.getAllGopalRecord();
		return al;
	}

	// insertGopalRecord(int id, String name) -> This method use for Insert a single record from Service Class
	public void insertGopalRecord(int id, String name) throws Exception {
		GopalService gs = new GopalService();
		gs.insertGopalRecord(id, name);
	}

	// updateGopalRecord(int id, String name) -> This method use for Update a single record from Service Class
	public void updateGopalRecord(int id, String name) throws Exception {
		GopalService gs = new GopalService();
		gs.updateGopalRecord(id, name);
	}
	
	// deleteGopalRecord(int id) -> This method use for Delete a single record from Service Class
	public void deleteGopalRecord(int id) throws Exception {
		GopalService gs = new GopalService();
		gs.deleteGopalRecord(id);
	}
	
	// Main Controller Class
	public static void main(String[] args) throws Exception {
		GopalController gc = new GopalController();
		gc.getAllGopalRecord();
		//gc.insertGopalRecord(7, "Gopal");
		//gc.updateGopalRecord(7, "Golu");
		//gc.deleteGopalRecord(7);
	
	}
}
