package com.configuration;

import org.hibernate.cfg.Configuration;

import com.entity.Gopal;

//DataBase Connection Done in a Single class  
public class DBConfiguration {

//	// We can use Single method in multiple classes

	public static Configuration getConnection() {

		Configuration cfg = new Configuration();
		cfg.addAnnotatedClass(Gopal.class).configure();	
		return cfg;
	}
}
