package com.service;


import java.util.List;

import com.dao.GopalDao;
import com.entity.Gopal;

// Business logic
public class GopalService {

	// getAllGopalRecord() -> This method use for Get All Data in DataBase
	public List<Gopal> getAllGopalRecord() throws Exception {
		GopalDao gd = new GopalDao();
		List<Gopal> al=gd.getAllGopalRecord();
		return al;
	}

	// insertGopalRecord(int id, String name) -> This method use for Insert a single Data in DataBase
	public void insertGopalRecord(int id, String name) throws Exception {
		GopalDao gd = new GopalDao();
		gd.insertGopalRecord(id,name);
	}

	// updateGopalRecord(int id, String name) -> This method use for Update a single Data in DataBase
	public void updateGopalRecord(int id, String name) throws Exception{
		GopalDao gd = new GopalDao();
		gd.updateGopalRecord(id,name);
	}

	// deleteGopalRecord(int id) -> This method use for Delete a single Data in DataBase
	public void deleteGopalRecord(int id) throws Exception {
		GopalDao gd = new GopalDao();
		gd.deleteGopalRecord(id);
	}
}
