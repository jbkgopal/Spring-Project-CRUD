package com.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.configuration.DBConfiguration;
import com.entity.Gopal;

// Data Transfer from DataBase - setData and getData
public class GopalDao {

	// getAllGopalRecord() -> This method use for Get All Data in DataBase
	public List<Gopal> getAllGopalRecord() throws Exception {
		Configuration cfg = DBConfiguration.getConnection();
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Query query = ss.createQuery("from Gopal");
		List<Gopal> list = query.list();
		for (Gopal gopal : list) {
			System.out.println(gopal);
		}
		return list;
	}

	// insertGopalRecord(int id, String name) -> This method use for Insert a single
	// Data in DataBase
	public void insertGopalRecord(int id, String name) throws Exception {
		Configuration cfg = DBConfiguration.getConnection();
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		Gopal insert = new Gopal();
		insert.setId(id);
		insert.setName(name);
		ss.save(insert);
		tx.commit();
	}

	// updateGopalRecord(int id, String name) -> This method use for Update a single
	// Data in DataBase
	public void updateGopalRecord(int id, String name) throws Exception {
		Configuration cfg = DBConfiguration.getConnection();
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		Gopal update = new Gopal();
		update.setId(id);
		update.setName(name);
		ss.update(update);
		tx.commit();
	}

	// deleteGopalRecord(int id) -> This method use for Delete a single Data in
	// DataBase
	public void deleteGopalRecord(int id) throws Exception {
		Configuration cfg = DBConfiguration.getConnection();
		SessionFactory sf = cfg.buildSessionFactory();
		Session ss = sf.openSession();
		Transaction tx = ss.beginTransaction();
		Gopal update = new Gopal();
		update.setId(id);
		ss.delete(update);
		tx.commit();
	}

}
